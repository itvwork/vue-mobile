# 核心概念

在这一章，我们将会学到 Vue 的这些核心概念。他们是：
  - [State](state.md)
  - [Getter](getters.md)
  - [Mutation](mutations.md)
  - [Action](actions.md)
  - [Module](modules.md)

深入理解所有的概念对于使用 Vuex 来说是必要的。

让我们开始吧。
